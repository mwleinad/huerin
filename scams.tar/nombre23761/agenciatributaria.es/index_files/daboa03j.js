function foc(){
    document.getElementById("NIF").focus();   
	
//  foco cuando devuelve el programa un error de Apellido, Referencia o de Casilla
    if (document.getElementById("APELLIDO").className == "AEAT_error")
	   {document.getElementById("APELLIDO").focus();}

	if (document.getElementById("REFERENCIA").className == "AEAT_error")
		if (document.forms.FORM1.MARCA[0].checked)
		   {document.getElementById("REFERENCIA").focus();} 
		else{document.getElementById("NIF").focus();} 
   
    if (campa�a == 'S' &&
       (fecha.substr(4,4) < "0424" || 
       (fecha.substr(4,4) >= "0424" && fecha.substr(4,4) <= "0701"))){ 
        if (document.getElementById("CASILLA1").className == "AEAT_error" ||
			document.getElementById("DECIMAL1").className == "AEAT_error")
	       {document.getElementById("CASILLA1").focus();} 
	}
    if ((campa�a == 'S' &&
		(fecha.substr(4,4) >  "0701" || 
        (fecha.substr(4,4) >= "0424" && fecha.substr(4,4) <= "0701"))) ||
		 campa�a == 'N'){
		if (document.getElementById("CASILLA2").className == "AEAT_error" ||
			document.getElementById("DECIMAL2").className == "AEAT_error")
	       {document.getElementById("CASILLA2").focus();}  
	}
}

function cargarErrores(){
  if (idioma != 'ES' &&
	  idioma != 'CA' && idioma != 'CA-ES' &&
	  idioma != 'GL' && idioma != 'GL-ES' &&
	  idioma != 'CA-VA')
    { idioma = 'ES'}
  switch (idioma) {
	      case 'ES':
					titulo = "Corrija los siguientes errores";
					error1 = "Introduzca el NIF"; 
					error2 = "Introduzca el apellido";
                    error3 = "Introduzca referencia, casilla o marca de no declarante";
					error4 = "Introduzca s�lo referencia, casilla o marca de no declarante";
                    error5 = "La casilla no es num�rica";
                    error6 = "Introduzca casilla con decimales";
					error7 = "No rellene datos para esta opci�n";
					//error8 = "Para esta opci�n no rellene el NIF Certificado"; 
					error8 = "Referencia err�nea, revise la longitud y debe finalizar con una letra";	
					error9 = "Introduzca referencia"; 
					error10 = "Introduzca casilla"; 
					error11 = "Espere, su petici�n se est� procesando";
					error12 = "No rellene datos para esta opci�n";	
                    break;
          case 'CA': case 'CA-ES': 
					titulo = "Corregeixi els seg�ents errors";
					error1 = "Introdueixi el NIF"; 
					error2 = "Introdueixi el cognom";
                    error3 = "Introdueixi la refer�ncia, casella o marca de no declarant";
					error4 = "Introdueixi solament la refer�ncia, casella o marca de no declarant";
                    error5 = "La casella no �s num�rica";
                    error6 = "Introdueixi la casella amb decimals";
					error7 = "No emplene dades per a aquesta opci�";
					//error8 = "Per a aquesta opci� no consigni el NIF certificat";  
					error8 = "Refer�ncia err�nia (revisi'n la longitud); ha de finalitzar amb una lletra.";	
					error9 = "Introdueixi la refer�ncia"; 
					error10 = "Introdueixi la casella"; 
                    error11 = "Espere, la seua petici� s�st�  processant";
					error12 = "No emplene dades per a aquesta opci�";	
                    break;
          case 'GL': case 'GL-ES':
					titulo = "Corrixa os seguintes erros";
					error1 = "Introduza o NIF"; 
					error2 = "Introduza o apelido";
                    error3 = "Introduza referencia, casa ou marca de non declarante";
					error4 = "Introduza s� referencia, casa ou marca de non declarante";
                    error5 = "A casa non � num�rica";
                    error6 = "Introduza casa con decimals";
					error7 = "Non encha datos para esta opci�n";
					//error8 = "Para esta opci�n no cubra o NIF certificado";  
					error8 = "Referencia err�nea, revise a lonxitude e debe finalizar cunha letra";		
					error9 = "Introduza referencia"; 
					error10 = "Introduza casa"; 
					error11 = "Espere, a s�a petici�n estase procesando"; 
					error12 = "Non encha datos para esta opci�n";	
                    break;
		  case 'CA-VA':
					titulo = "Corregisca els seg�ents errors";
					error1 = "Introdu�sca el NIF"; 
					error2 = "Introdu�sca el cognom";
                    error3 = "Introdu�sca la refer�ncia, casella o marca de no declarant";
					error4 = "Introdu�sca solament la refer�ncia, casella o marca de no declarant";
                    error5 = "La casella no �s num�rica";
                    error6 = "Introdu�sca la casella amb decimals";
					error7 = "No farcixca senyes per a esta opci�";
					//error8 = "Per a esta opci� no consigne el NIF certificat";  
					error8 = "Refer�ncia err�nia: reviseu-ne la longitud, i ha de finalitzar amb una lletra.";				
					error9 = "Introdu�sca la refer�ncia"; 
					error10 = "Introdu�sca la casella"; 
					error11 = "Espere, la seua petici� s�st�  processant"; 
					error12 = "No emplene dades per a aquesta opci�";	
                    break;
  }
}

function Limpiar(){
  // si valida = "S" es que ha ido al programa y con el bot�n Atr�s de Windows se quedaban los errores de programa antiguos como 'Ref.err�nea'
	if (document.getElementById("VALIDA").value == 'S')
	{	Resetear_errores();
		document.getElementById("errores").className = "oculto";
	}
	document.getElementById("NIF").value = QuitaBlancos(document.getElementById("NIF").value);
	if (document.getElementById("NIF").value == '')
	{	document.getElementById("NIF").value = '';
		document.getElementById("NIF").className = '';
	}
	document.getElementById("APELLIDO").value = QuitaBlancos(document.getElementById("APELLIDO").value);
	if (document.getElementById("APELLIDO").value == '')
	{	document.getElementById("APELLIDO").value = '';
		document.getElementById("APELLIDO").className = '';
	}  
	document.getElementById("REFERENCIA").value = QuitaBlancos(document.getElementById("REFERENCIA").value);
	if (document.getElementById("REFERENCIA").value == '')
	{	document.getElementById("REFERENCIA").value = '';
		document.getElementById("REFERENCIA").className = '';
	}
	if (campa�a == 'S' &&
		(fecha.substr(4,4) < "0424" || 
		(fecha.substr(4,4) >= "0424" && fecha.substr(4,4) <= "0701")))
	{	document.getElementById("CASILLA1").value = QuitaBlancos(document.getElementById("CASILLA1").value);
		document.getElementById("DECIMAL1").value = QuitaBlancos(document.getElementById("DECIMAL1").value);
		if (document.getElementById("CASILLA1").value == '')
		{	document.getElementById("CASILLA1").value = '';}
		if (document.getElementById("DECIMAL1").value == '')
		{	document.getElementById("DECIMAL1").value = '';}
	}
	if ((campa�a == 'S' &&
		(fecha.substr(4,4) >  "0701" || 
		(fecha.substr(4,4) >= "0424" && fecha.substr(4,4) <= "0701"))) ||
		campa�a == 'N')
	{	document.getElementById("CASILLA2").value = QuitaBlancos(document.getElementById("CASILLA2").value);
		document.getElementById("DECIMAL2").value = QuitaBlancos(document.getElementById("DECIMAL2").value);
		if (document.getElementById("CASILLA2").value == '')
		{	document.getElementById("CASILLA2").value = '';}
		if (document.getElementById("DECIMAL2").value == '')
		{	document.getElementById("DECIMAL2").value = '';} 
	}

  // proteger campos del boton radio
   if (document.getElementById("REFERENCIA").value == '' )
      {document.getElementById("REFERENCIA").disabled=true; 
       document.getElementById("REFERENCIA").style.background="#e3e3e2";}
   if (campa�a == 'S' &&
      (fecha.substr(4,4) < "0424" || 
      (fecha.substr(4,4) >= "0424" && fecha.substr(4,4) <= "0701"))){ 
	  if (document.getElementById("CASILLA1").value == '' &&
		  document.getElementById("DECIMAL1").value == '')
	     {protegerCasilla();}
   }
   if ((campa�a == 'S' &&
	   (fecha.substr(4,4) >  "0701" || 
       (fecha.substr(4,4) >= "0424" && fecha.substr(4,4) <= "0701"))) ||
		campa�a == 'N'){
	  if (document.getElementById("CASILLA2").value == '' &&
		  document.getElementById("DECIMAL2").value == '')
	     {protegerCasilla();}
   } 	 
}

// limpia el formulario boton reset
function Resetear(form){
	if (form.id == 'FORM1')
	   {document.getElementById("errores").innerHTML = '';
        document.getElementById("errores").className = "oculto"; 
	    document.getElementById("NIF").value = '';
        document.getElementById("APELLIDO").value = '';
	    document.getElementById("REFERENCIA").value = '';
        if (campa�a == 'S' &&
           (fecha.substr(4,4) < "0424" || 
           (fecha.substr(4,4) >= "0424" && fecha.substr(4,4) <= "0701"))){ 
	        document.getElementById("CASILLA1").value = ''; 
	        document.getElementById("DECIMAL1").value = '';
		    document.getElementById("CASILLA1").className = '';  
		    document.getElementById("DECIMAL1").className = '';  
	    }
	    if ((campa�a == 'S' &&
		    (fecha.substr(4,4) >  "0701" || 
            (fecha.substr(4,4) >= "0424" && fecha.substr(4,4) <= "0701"))) ||
		     campa�a == 'N'){
	        document.getElementById("CASILLA2").value = '';
	        document.getElementById("DECIMAL2").value = '';
	        document.getElementById("CASILLA2").className = '';  
		    document.getElementById("DECIMAL2").className = '';  
	    }
	    document.getElementById("NIF").className = '';  
	    document.getElementById("APELLIDO").className = '';  
        document.getElementById("REFERENCIA").className = '';  

		// proteger los campos radio 
		document.forms.FORM1.MARCA[0].checked=false; 
        document.forms.FORM1.MARCA[3].checked=false;  
		document.forms.FORM1.MARCA[3].className = ''; 	
		document.getElementById("REFERENCIA").disabled=true; 
		document.getElementById("REFERENCIA").style.background="#e3e3e2";
		protegerCasilla(); 
	}
	else		
	   {document.getElementById("errores").innerHTML = '';
        document.getElementById("errores").className = "oculto";}   
}

// limpia los errores del formulario cuando todo se valida bien, para que con el bot�n atr�s no se queden errores falsos
function Resetear_errores(){
	   document.getElementById("errores").innerHTML = '';
       document.getElementById("errores").className = "oculto";	
       if (campa�a == 'S' &&
          (fecha.substr(4,4) < "0424" || 
          (fecha.substr(4,4) >= "0424" && fecha.substr(4,4) <= "0701"))){ 
		   document.getElementById("CASILLA1").className = '';  
		   document.getElementById("DECIMAL1").className = '';  
	   }
	   if ((campa�a == 'S' &&
		   (fecha.substr(4,4) >  "0701" || 
           (fecha.substr(4,4) >= "0424" && fecha.substr(4,4) <= "0701"))) ||
		    campa�a == 'N'){
		   document.getElementById("CASILLA2").className = '';  
		   document.getElementById("DECIMAL2").className = '';  
	   }
	   document.getElementById("NIF").className = '';  
	   document.getElementById("APELLIDO").className = '';  
       document.getElementById("REFERENCIA").className = '';  
	   document.forms.FORM1.MARCA[3].className = ''; 	
}

function Comprobar_sin(){
  var total = 0;
  var sw_casilla1 = '';
  var sw_casilla2 = '';  
  var sw_error_opcion = '';
  var foco = '';
  var texto_error='';  
  var class_casilla = 'AEAT_error '; 
  
  //Limpiar();
  Resetear_errores(); 
  cargarErrores();

  // validaci�n
  if (document.getElementById("NIF").value == ""){
      document.getElementById("NIF").className = "AEAT_error";  
	  texto_error += '<a href=""><label for="#NIF"><li>' + error1 + '</li></label></a>';
      foco = "NIF";}   

  if (document.getElementById("APELLIDO").value == ""){
	  document.getElementById("APELLIDO").className = "AEAT_error"; 
	  texto_error += '<a href="#APELLIDO"><li>' + error2 + '</li></a>';
	  if (foco == '')
	  { foco = "APELLIDO"}}

  if (document.forms.FORM1.MARCA[0].checked){
	  total += 1;
      if (document.getElementById("REFERENCIA").value == "" ){
		  document.getElementById("REFERENCIA").className = "AEAT_error";
          texto_error += '<a href="#REFERENCIA"><li>' + error9 + '</li></a>'; 
		  sw_error_opcion = 'S';
          if (foco == ''){
  	          foco = "REFERENCIA"}}
  	  else{
			/* nuevo */
			if (document.forms.FORM1.EJER_FISCAL.value < 2012) {
			/* fin nuevo */
			if ((document.getElementById("REFERENCIA").value.length !=16 &&
				document.getElementById("REFERENCIA").value.length !=19) ||
				(
				(document.getElementById("REFERENCIA").value.length ==16 &&   
				(!(isNaN(document.getElementById("REFERENCIA").value.substr(15,1))))) || 
				(document.getElementById("REFERENCIA").value.length ==19 && 
				(!(isNaN(document.getElementById("REFERENCIA").value.substr(18,1)))))
				) 	
			   )
				{ document.getElementById("REFERENCIA").className = "AEAT_error";
				texto_error += '<a href="#REFERENCIA"><li>' + error8 + '</li></a>';
				sw_error_opcion = 'S';	
				if (foco == ''){
  					foco = "REFERENCIA"}} 
			/* nuevo */
			}
			else {
				 if (document.getElementById("REFERENCIA").value.length < 10) {
					 document.getElementById("REFERENCIA").className = "AEAT_error"; 
					 texto_error += '<a href="#REFERENCIA"><li>' + error8 + '</li></a>';
					 sw_error_opcion = 'S';	
					if (foco == '')	{foco = "REFERENCIA"}
					} 
			}
			/* fin nuevo */
		}
  }

  if (campa�a == 'S' &&
     (fecha.substr(4,4) < "0424" || 
     (fecha.substr(4,4) >= "0424" && fecha.substr(4,4) <= "0701"))){ 
      if (document.forms.FORM1.MARCA[1].checked){
		  total += 1;
	      if (document.getElementById("CASILLA1").value == "" &&
              document.getElementById("DECIMAL1").value == "" ){ 
			  document.getElementById("CASILLA1").className = "AEAT_error";
			  document.getElementById("DECIMAL1").className = "AEAT_error";
		      texto_error += '<a href="#CASILLA1"><li>' + error10 + '</li></a>'; 
			  sw_error_opcion = 'S';  
			  if (foco == ''){
	              foco = "CASILLA1"}}
		  else{sw_casilla1 = 'S';}
  }}

  if ((campa�a == 'S' &&
	  (fecha.substr(4,4) >  "0701" || 
      (fecha.substr(4,4) >= "0424" && fecha.substr(4,4) <= "0701"))) ||
	   campa�a == 'N'){
      if (document.forms.FORM1.MARCA[2].checked){
		  total += 1;
	      if (document.getElementById("CASILLA2").value == "" &&
              document.getElementById("DECIMAL2").value == "" ){ 
			  document.getElementById("CASILLA2").className = "AEAT_error";
			  document.getElementById("DECIMAL2").className = "AEAT_error";
			  texto_error += '<a href="#CASILLA2"><li>' + error10 + '</li></a>'; 
			  sw_error_opcion = 'S';  
		      if (foco == ''){
	              foco = "CASILLA2"}}
		  else{sw_casilla2 = 'S';}
  }}

  if (document.forms.FORM1.MARCA[3].checked){
      total +=1;}

  if (total == 0){
      document.getElementById("REFERENCIA").className = "AEAT_error";  
	  if (campa�a == 'S' &&
         (fecha.substr(4,4) < "0424" || 
         (fecha.substr(4,4) >= "0424" && fecha.substr(4,4) <= "0701"))){ 
	      document.getElementById("CASILLA1").className = class_casilla;  
	      document.getElementById("DECIMAL1").className = class_casilla; 
      }
      if ((campa�a == 'S' &&
	     (fecha.substr(4,4) >  "0701" || 
         (fecha.substr(4,4) >= "0424" && fecha.substr(4,4) <= "0701"))) ||
		  campa�a == 'N'){
	      document.getElementById("CASILLA2").className = class_casilla;  
	      document.getElementById("DECIMAL2").className = class_casilla;  
      } 

	  if (sw_error_opcion == '')
	  {texto_error += '<a href="#REFERENCIA"><li>' + error3 + '</li></a>';}
	  
      if (foco == '')
	  	 { foco = "NIF"}}

  if (total == 1){
      if (campa�a == 'S' &&
         (fecha.substr(4,4) < "0424" || 
         (fecha.substr(4,4) >= "0424" && fecha.substr(4,4) <= "0701"))){ 
          if (sw_casilla1 = 'S'){
			  // admitir negativos
			  //document.getElementById("CASILLA1").value = document.getElementById("CASILLA1").value.replace(/[ ]/g, '');	
			  var cadena = document.getElementById("CASILLA1").value;var conta = 0;
			  for (i=0;i<cadena.length;i++){if (cadena.substr(i,1) == '-'){conta += 1;}}
			  if (document.getElementById("CASILLA1").value.substr(0,1) == '-' && conta == 1) 
				 {document.getElementById("CASILLA1").value = document.getElementById("CASILLA1").value.replace(/[-]/, '');}
			  //
	          if (isNaN(document.getElementById("CASILLA1").value) ||
		          isNaN(document.getElementById("DECIMAL1").value)){
				        document.getElementById("CASILLA1").className = class_casilla; 
						document.getElementById("DECIMAL1").className = class_casilla;
				        texto_error += '<a href="#CASILLA1"><li>' + error5 + '</li></a>';
	                    if (foco == '')
				           { foco = "CASILLA1"}}
              else {
                  if ((document.getElementById("CASILLA1").value == "" && document.getElementById("DECIMAL1").value != "") ||
                      (document.getElementById("CASILLA1").value != "" && document.getElementById("DECIMAL1").value == "")){
					   document.getElementById("CASILLA1").className = class_casilla;
					   document.getElementById("DECIMAL1").className = class_casilla;
					   texto_error += '<a href="#CASILLA1"><li>' + error6 + '</li></a>';
                       if (foco == '')
	                      { foco = "CASILLA1"}} 
                  else {
						if (texto_error == '')
							    {document.getElementById("VALIDA").value = "S"; 
                                 document.getElementById("errores").className = "oculto"; 
						         return controlar_tiempo();}}	} } } 

       if ((campa�a == 'S' &&
		   (fecha.substr(4,4) >  "0701" || 
           (fecha.substr(4,4) >= "0424" && fecha.substr(4,4) <= "0701"))) ||
		    campa�a == 'N'){
        	if (sw_casilla2 = 'S'){
				// admitir negativos
				//document.getElementById("CASILLA2").value = document.getElementById("CASILLA2").value.replace(/[ ]/g, '');	
				var cadena = document.getElementById("CASILLA2").value;var conta = 0;
			    for (i=0;i<cadena.length;i++){if (cadena.substr(i,1) == '-'){conta += 1;}}
			    if (document.getElementById("CASILLA2").value.substr(0,1) == '-' && conta == 1) 
				   {document.getElementById("CASILLA2").value = document.getElementById("CASILLA2").value.replace(/[-]/, '');}
				//
	            if (isNaN(document.getElementById("CASILLA2").value) ||
		            isNaN(document.getElementById("DECIMAL2").value)){
					      document.getElementById("CASILLA2").className = class_casilla; 
						  document.getElementById("DECIMAL2").className = class_casilla;
						 texto_error += '<a href="#CASILLA2"><li>' + error5 + '</li></a>';
						 if (foco == '')
							 { foco = "CASILLA2"}}
              else {
                if ((document.getElementById("CASILLA2").value == "" && document.getElementById("DECIMAL2").value != "") ||
                    (document.getElementById("CASILLA2").value != "" && document.getElementById("DECIMAL2").value == "")){
					 document.getElementById("CASILLA2").className = class_casilla; 
					 document.getElementById("DECIMAL2").className = class_casilla;
					 texto_error += '<a href="#CASILLA2"><li>' + error6 + '</li></a>';
                     if (foco == '')
	                   { foco = "CASILLA2"}} 
                else {
					 if (texto_error == '')
							  {document.getElementById("VALIDA").value = "S"; 
                               document.getElementById("errores").className = "oculto"; 
						       return controlar_tiempo();}}	} } } 
   }
	  
   document.getElementById(foco).focus();
   if (texto_error != '')
	{document.getElementById("errores").className = "AEAT_bloque_errores";	
   document.getElementById("errores").innerHTML = '<strong>' + titulo + '</strong><ul>' + texto_error + '</ul>';}
   return false

}

function Comprobar_con(){
	var texto_error=''; 
	var sw_error='';
	var sw_casilla1='';
	var sw_casilla2='';

	Limpiar();
	Resetear_errores(); 
	cargarErrores();

	if (campa�a == 'S' && fecha.substr(4,4) < "0424"){ 
		if (document.getElementById("CASILLA1").value != "" ||
            document.getElementById("DECIMAL1").value != "")
			{sw_casilla1 = 'S';
			document.getElementById("CASILLA1").className = "AEAT_error";   
			document.getElementById("DECIMAL1").className = "AEAT_error";  	
			texto_error = '<a href="#CASILLA1"><li>' + error7 + '</li></a>';		
			document.getElementById("CASILLA1").focus();}
		}
    else {
	        if (campa�a == 'S' && 
			   (fecha.substr(4,4) >= "0424" & fecha.substr(4,4) <= "0630")){   
				if (document.getElementById("CASILLA2").value != "" ||
				    document.getElementById("DECIMAL2").value != "")
					{sw_casilla2 = 'S';
					document.getElementById("CASILLA2").className = "AEAT_error";   
					document.getElementById("DECIMAL2").className = "AEAT_error";  	
					texto_error = '<a href="#CASILLA2"><li>' + error7 + '</li></a>';		
					document.getElementById("CASILLA2").focus();}	
	            if (document.getElementById("CASILLA1").value != "" ||
				    document.getElementById("DECIMAL1").value != "")
					{sw_casilla1 = 'S';
					document.getElementById("CASILLA1").className = "AEAT_error";   
					document.getElementById("DECIMAL1").className = "AEAT_error";  	
					texto_error = '<a href="#CASILLA1"><li>' + error7 + '</li></a>';		
					document.getElementById("CASILLA1").focus();}
		    }
	        else {
		        if (campa�a == 'N' || fecha.substr(4,4) >= "0629"){
	               if (document.getElementById("CASILLA2").value != "" ||
					    document.getElementById("DECIMAL2").value != "")
						{sw_casilla2 = 'S';
						document.getElementById("CASILLA2").className = "AEAT_error";   
						document.getElementById("DECIMAL2").className = "AEAT_error";  	
						texto_error = '<a href="#CASILLA2"><li>' + error7 + '</li></a>';		
						document.getElementById("CASILLA2").focus();}	
			}
   } }
 
	if (document.forms.FORM1.MARCA[3].checked==true)
		{sw_error ='S';
		document.forms.FORM1.MARCA[3].className = "AEAT_error"; 
		texto_error = '<a href="#NODECLA"><li>' + error7 + '</li></a>';	
		document.forms.FORM1.MARCA[3].focus();}
	if (document.getElementById("REFERENCIA").value != "")
		{sw_error ='S';
		document.getElementById("REFERENCIA").className = "AEAT_error"; 
		texto_error = '<a href="#REFERENCIA"><li>' + error7 + '</li></a>';	
		document.getElementById("REFERENCIA").focus();}
	if (document.getElementById("APELLIDO").value != "")
		{sw_error ='S';
		document.getElementById("APELLIDO").className = "AEAT_error"; 
		texto_error = '<a href="#APELLIDO"><li>' + error7 + '</li></a>';		
		document.getElementById("APELLIDO").focus();}
	if (document.getElementById("NIF").value != "")
		{sw_error ='S';
		document.getElementById("NIF").className = "AEAT_error";   
		texto_error = '<a href="#NIF"><li>' + error7 + '</li></a>';		
		document.getElementById("NIF").focus();}

    if (campa�a == 'S' && fecha.substr(4,4) < "0424"){ 
	    if (sw_error == '' &&
            sw_casilla1 == ''){ 
	        document.getElementById("errores").className = "oculto"; 
			document.getElementById("VALIDA0").value = "S"; 
			document.forms.FORM1.MARCA[0].checked=false; 
			document.forms.FORM1.MARCA[1].checked=false; 	  	
			return controlar_tiempo();}
		}
        else {
	        if (campa�a == 'S' && 
			   (fecha.substr(4,4) >= "0424" & fecha.substr(4,4) <= "0630")){   
				if (sw_error == '' &&
					sw_casilla1 == '' &&
					sw_casilla2 == ''){ 
					document.getElementById("errores").className = "oculto"; 
					document.getElementById("VALIDA0").value = "S"; 
					document.forms.FORM1.MARCA[0].checked=false; 
					document.forms.FORM1.MARCA[1].checked=false; 
					document.forms.FORM1.MARCA[2].checked=false; 	
					return controlar_tiempo();}
		    }
	        else {
		        if (campa�a == 'N' || fecha.substr(4,4) >= "0629"){
					if (sw_error == '' &&
						sw_casilla1 == '' &&
						sw_casilla2 == ''){ 
						document.getElementById("errores").className = "oculto"; 
						document.getElementById("VALIDA0").value = "S"; 
						document.forms.FORM1.MARCA[0].checked=false; 
						document.forms.FORM1.MARCA[2].checked=false; 	
						return controlar_tiempo();}
				}
   } }
 if (texto_error != '')
	{document.getElementById("errores").className = "AEAT_bloque_errores";	
	document.getElementById("errores").innerHTML = '<strong>' + titulo + '</strong><ul>' + texto_error + '</ul>';}
	return false
}  

function cambiaRadio(campo){ 
	 Resetear_errores();
	 document.getElementById("errores").className = "";	  
	 
     if (document.forms.FORM1.MARCA[0].checked) 
		{document.getElementById("REFERENCIA").disabled=false;
		 document.getElementById("REFERENCIA").style.background="";}
	 else
	   {document.getElementById("REFERENCIA").value = '';
	    document.getElementById("REFERENCIA").disabled=true; 
		document.getElementById("REFERENCIA").style.background="#e3e3e2";}	  
	 
	 if (campa�a == 'S' &&
        (fecha.substr(4,4) < "0424" || 
        (fecha.substr(4,4) >= "0424" && fecha.substr(4,4) <= "0701"))){ 
	    if (document.forms.FORM1.MARCA[1].checked) 
		{  
			document.getElementById("CASILLA1").disabled=false;
			document.getElementById("DECIMAL1").disabled=false; 
		    document.getElementById("CASILLA1").style.background=""; 
			document.getElementById("DECIMAL1").style.background="";  
            if (fecha.substr(4,4) >= "0424" && fecha.substr(4,4) <= "0701")
              { document.forms.FORM1.MARCA[2].checked=false;
			    document.getElementById("CASILLA2").disabled=true; 
                document.getElementById("DECIMAL2").disabled=true; 
			    document.getElementById("CASILLA2").style.background="#e3e3e2"; 
			    document.getElementById("DECIMAL2").style.background="#e3e3e2";}
		}
		else
	    {document.getElementById("CASILLA1").value = '';
		 document.getElementById("DECIMAL1").value = '';}  
	 }

     if ((campa�a == 'S' &&
		 (fecha.substr(4,4) >  "0701" || 
         (fecha.substr(4,4) >= "0424" && fecha.substr(4,4) <= "0701"))) ||
		  campa�a == 'N'){
	    if (document.forms.FORM1.MARCA[2].checked) 
		{   
			document.getElementById("CASILLA2").disabled=false;
			document.getElementById("DECIMAL2").disabled=false; 
		    document.getElementById("CASILLA2").style.background=""; 
			document.getElementById("DECIMAL2").style.background=""; 
            if (fecha.substr(4,4) >= "0424" && fecha.substr(4,4) <= "0701")
              { document.forms.FORM1.MARCA[1].checked=false;
			    document.getElementById("CASILLA1").disabled=true; 
                document.getElementById("DECIMAL1").disabled=true; 
			    document.getElementById("CASILLA1").style.background="#e3e3e2"; 
			    document.getElementById("DECIMAL1").style.background="#e3e3e2";}
		}
		else
		{document.getElementById("CASILLA2").value = '';
		 document.getElementById("DECIMAL2").value = '';}   
	 }

	 if (document.forms.FORM1.MARCA[0].checked ||
	     document.forms.FORM1.MARCA[3].checked){ 
	     protegerCasilla();
	 }

}

function protegerCasilla(){
         if (campa�a == 'S' && fecha.substr(4,4) < "0424"){ 
			 document.forms.FORM1.MARCA[1].checked=false; 
			 document.getElementById("CASILLA1").disabled=true; 
             document.getElementById("DECIMAL1").disabled=true;
			 document.getElementById("CASILLA1").style.background="#e3e3e2"; 
			 document.getElementById("DECIMAL1").style.background="#e3e3e2"; }  
		 if (campa�a == 'S' &&
		    (fecha.substr(4,4) >= "0424" && fecha.substr(4,4) <= "0701")){ 
			 if (document.getElementById("CASILLA1").value == '' &&
		         document.getElementById("DECIMAL1").value == '')
			    {document.forms.FORM1.MARCA[1].checked=false; 
			     document.getElementById("CASILLA1").disabled=true; 
                 document.getElementById("DECIMAL1").disabled=true; 
			     document.getElementById("CASILLA1").style.background="#e3e3e2"; 
			     document.getElementById("DECIMAL1").style.background="#e3e3e2"; } 
			 if (document.getElementById("CASILLA2").value == '' &&
		         document.getElementById("DECIMAL2").value == '') 
			    {document.forms.FORM1.MARCA[2].checked=false;  
			     document.getElementById("CASILLA2").disabled=true; 
                 document.getElementById("DECIMAL2").disabled=true;
			     document.getElementById("CASILLA2").style.background="#e3e3e2"; 
			     document.getElementById("DECIMAL2").style.background="#e3e3e2"; }
		 }   
		 if ((campa�a == 'S' && fecha.substr(4,4) > "0701") ||
			  campa�a == 'N'){	
			 document.forms.FORM1.MARCA[2].checked=false; 
			 document.getElementById("CASILLA2").disabled=true; 
             document.getElementById("DECIMAL2").disabled=true;
			 document.getElementById("CASILLA2").style.background="#e3e3e2"; 
			 document.getElementById("DECIMAL2").style.background="#e3e3e2"; }  
}

function cambiarejer(){
	var texto_error=''; 
	cargarErrores();
	var ejer_solicitado = document.getElementById("EJERCICIO").value;
	if (ejer_solicitado == '' ||
		ejer_solicitado == '    ')
	{	return false
	}
	else
	{
		if (ejer_fiscal == ejer_solicitado)
		{	return false
		}
		else
		{
			document.forms.FORM3.EJERCICIO.value=document.getElementById("EJERCICIO").value;
			document.forms.FORM3.action="/es13/s/dabodaboa03w";
			document.forms.FORM3.submit();
		}
	}
}

///Para eliminar los blancos y comprobar si lleva valor
function QuitaBlancos(valor)
{
	var primerBlanco = /^ /;
	var ultimoBlanco = / $/;
	var variosBlancos = /[ ]+/g;
	var texto = valor;
	var textoTratado; 
	if (texto.length!=1)
	{
		texto = texto.replace(primerBlanco,"");
		texto = texto.replace(ultimoBlanco,"");
		textoTratado = texto.replace(variosBlancos,"");    
	}
	else
	{
		if (texto==" ")
		{
			textoTratado="";
		}
		else
		{
			textoTratado=texto;
		}
	}  
	return(textoTratado);
}

var antes=0;
function controlar_tiempo() {
ahora=new Date().getTime();
if ((ahora-antes)<=30000) {noenviar=true;alert(error11)} else {noenviar=false; antes=ahora}
if (noenviar==true){return false}
}
